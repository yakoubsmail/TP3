import os
import discord
from dotenv import load_dotenv

load_dotenv(dotenv_path="config")
client = discord.Client()
from discord import Client


class MyBot(Client):
    def __init__(self):
        super().__init__()

    async def on_ready(self):
        self.log.infolog(f"{self.user} has connected to Discord!")

